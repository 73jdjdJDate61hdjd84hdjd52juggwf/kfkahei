package com.heima.kafka;

/**
 * @Author dayuan
 * @Date 2019/7/11 14:40
 */
public abstract class KafkaContext {
    public static String brokerList = "localhost:9092";
    public static String topic = "heima";
    public static String groupId = "group.heima";
}
